import React from "react";
import { Link } from "react-router-dom";
import { Navbar } from "../components/dashboard/Navbar";
import { 
  ArrowLeft, CheckCircle2, ArrowRight, Layers, Users, Activity, 
  Scale, ShieldAlert, HelpCircle, User, ListTodo, Download, FileText
} from "lucide-react";

export function SessionResult() {
  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      <Navbar activePage="会议历史" />

      <main className="max-w-[1600px] mx-auto px-6 xl:px-12 py-6 pb-12">
        {/* Top Header */}
        <div className="flex items-center justify-between mb-4">
          <Link to="/workspace" className="flex items-center text-blue-600 font-medium text-sm gap-1 hover:underline">
            <ArrowLeft className="w-4 h-4" />
            返回工作台
          </Link>
          <div className="text-slate-500 text-sm">
            结束时间 2025-05-16 16:42
          </div>
        </div>

        {/* Hero Card */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm mb-6 flex flex-col lg:flex-row gap-8 items-start lg:items-center">
          {/* Left section */}
          <div className="flex items-center gap-5 lg:w-1/3">
            <div className="relative flex-shrink-0">
              <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center">
                <CheckCircle2 className="w-10 h-10 text-teal-500" fill="currentColor" stroke="white" strokeWidth={1} />
              </div>
              {/* Decorative elements - confetti */}
              <div className="absolute -top-2 -right-3 text-xl">🎉</div>
            </div>
            <div>
              <h2 className="text-2xl font-bold text-slate-900 tracking-tight">本次研讨已完成</h2>
              <p className="text-slate-500 mt-1 text-sm">高质量多 Agent 研讨已圆满结束</p>
            </div>
          </div>

          {/* Middle section */}
          <div className="flex-1 lg:px-8 lg:border-x border-slate-100 flex flex-col justify-center h-full min-h-[4rem]">
            <h3 className="text-slate-900 font-semibold mb-2">最终决议摘要</h3>
            <p className="text-slate-600 text-sm leading-relaxed mb-3">
              建议以 MVP 阶段（以停车优惠校检为核心）先行落地智能化票务，后续按路线图逐步扩展并迭代优化。
            </p>
            <button className="text-blue-600 text-sm font-medium flex items-center gap-1 w-fit hover:underline">
              查看完整结论 <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Right section */}
          <div className="flex items-center gap-8 lg:w-[30%] justify-end">
             <div className="text-center">
               <div className="flex items-center justify-center gap-1.5 text-slate-500 text-xs font-medium mb-2">
                 <div className="w-5 h-5 rounded bg-teal-50 flex items-center justify-center">
                   <Layers className="w-3 h-3 text-teal-600" />
                 </div>
                 讨论轮次
               </div>
               <div className="text-2xl font-bold text-slate-900">
                 6 <span className="text-sm font-normal text-slate-500">轮次</span>
               </div>
             </div>
             
             <div className="w-px h-12 bg-slate-100"></div>

             <div className="text-center">
               <div className="flex items-center justify-center gap-1.5 text-slate-500 text-xs font-medium mb-2">
                 <div className="w-5 h-5 rounded bg-blue-50 flex items-center justify-center">
                   <Users className="w-3 h-3 text-blue-600" />
                 </div>
                 参与角色
               </div>
               <div className="text-2xl font-bold text-slate-900">
                 6 <span className="text-sm font-normal text-slate-500">位</span>
               </div>
             </div>

             <div className="w-px h-12 bg-slate-100"></div>

             <div className="text-center">
               <div className="flex items-center justify-center gap-1.5 text-slate-500 text-xs font-medium mb-2">
                 <div className="w-5 h-5 rounded bg-indigo-50 flex items-center justify-center">
                   <Activity className="w-3 h-3 text-indigo-600" />
                 </div>
                 共识度
               </div>
               <div className="flex items-baseline justify-center gap-1">
                  <span className="text-2xl font-bold text-slate-900">82<span className="text-lg">%</span></span>
               </div>
               <div className="text-[11px] font-medium text-green-600 mt-0.5">
                 较高
               </div>
             </div>
          </div>
        </div>

        {/* Middle Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6 relative items-stretch">
          
          {/* Card 1: 最终结论 */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col h-full">
            <h3 className="flex items-center gap-2 text-slate-900 font-semibold mb-4">
              <div className="w-6 h-6 rounded-full bg-teal-50 flex items-center justify-center text-teal-600">
                <CheckCircle2 className="w-4 h-4" />
              </div>
              最终结论
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed mb-6 flex-1">
              同意采用分阶段实施路线。先以停车优惠校检为核心能力上线 MVP，覆盖主要停车场景与支付链路闭环，目标在 8 周内上线试点；并行完成数据埋点与风控框架搭建，为后续能力扩展与 AI 优化奠定基础。
            </p>
            <button className="w-fit text-sm text-blue-600 font-medium px-4 py-2 bg-blue-50 rounded-full hover:bg-blue-100 transition-colors">
              查看完整结论与投票记录
            </button>
          </div>

          {/* Card 2: 关键争议点 */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col h-full">
            <h3 className="flex items-center gap-2 text-slate-900 font-semibold mb-4">
              <div className="w-6 h-6 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
                <Scale className="w-4 h-4" />
              </div>
              关键争议点
            </h3>
            <div className="flex gap-4 flex-1">
              <div className="flex-1">
                <h4 className="text-xs font-medium text-teal-600 mb-2 flex items-center gap-1">
                  <div className="w-1 h-3 bg-teal-500 rounded-full"></div>
                  支持方观点
                </h4>
                <ul className="text-xs text-slate-600 space-y-2 pl-2 list-disc ml-2 marker:text-slate-300">
                  <li>MVP 快速验证价值，降低试错成本</li>
                  <li>停车场景覆盖率高，ROI 明确</li>
                  <li>技术路径清晰，可快速落地</li>
                </ul>
              </div>
              <div className="flex-1">
                <h4 className="text-xs font-medium text-orange-600 mb-2 flex items-center gap-1">
                  <div className="w-1 h-3 bg-orange-500 rounded-full"></div>
                  审慎方观点
                </h4>
                <ul className="text-xs text-slate-600 space-y-2 pl-2 list-disc ml-2 marker:text-slate-300">
                  <li>数据质量与权限治理需先行完善</li>
                  <li>多系统集成复杂度可能高于预期</li>
                  <li>风控与异常处理需更充分验证</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Card 3: 风险与前置条件 */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col h-full">
            <h3 className="flex items-center gap-2 text-slate-900 font-semibold mb-4">
              <div className="w-6 h-6 rounded-full bg-purple-50 flex items-center justify-center text-purple-600">
                <ShieldAlert className="w-4 h-4" />
              </div>
              风险与前置条件
            </h3>
            <div className="space-y-3 flex-1 flex flex-col">
              {[
                { name: "停车场数据接入进度不确定", type: "high" },
                { name: "支付渠道优惠策略对接复杂", type: "medium" },
                { name: "跨系统性能与稳定性风险", type: "medium" },
                { name: "前置条件：完成字段与接口对齐", type: "low" },
              ].map((item, i) => (
                <div key={i} className="flex flex-col gap-1 pb-2 border-b border-slate-50 last:border-0 last:pb-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="text-sm text-slate-700 leading-snug">{item.name}</div>
                    {item.type === 'high' && <span className="bg-red-50 text-red-600 text-[10px] px-1.5 py-0.5 rounded font-medium shrink-0">高</span>}
                    {item.type === 'medium' && <span className="bg-orange-50 text-orange-600 text-[10px] px-1.5 py-0.5 rounded font-medium shrink-0">中</span>}
                    {item.type === 'low' && <span className="bg-blue-50 text-blue-600 text-[10px] px-1.5 py-0.5 rounded font-medium shrink-0">低</span>}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Card 4: 待确认问题 */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col h-full">
            <h3 className="flex items-center gap-2 text-slate-900 font-semibold mb-4">
              <div className="w-6 h-6 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
                <HelpCircle className="w-4 h-4" />
              </div>
              待确认问题
            </h3>
            <ul className="text-sm text-slate-700 space-y-3 flex-1">
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 bg-slate-300 rounded-full mt-1.5 shrink-0"></span>
                <span className="leading-snug">优惠策略动态配置的粒度与审批流程？</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 bg-slate-300 rounded-full mt-1.5 shrink-0"></span>
                <span className="leading-snug">异常订单的自动补偿机制如何定义？</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 bg-slate-300 rounded-full mt-1.5 shrink-0"></span>
                <span className="leading-snug">上线后灰度范围与回滚策略？</span>
              </li>
            </ul>
            <button className="text-blue-600 text-sm font-medium mt-4 hover:underline text-left">
              共 3 个待确认问题
            </button>
          </div>

        </div>

        {/* Bottom Area */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column (Span 2) */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* 角色观点摘要 */}
            <div className="bg-transparent">
              <h3 className="flex items-center gap-2 text-slate-900 font-semibold mb-4">
                <User className="w-5 h-5 text-blue-600" />
                角色观点摘要
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3">
                {[
                  { name: "AI 主持人", icon: "🤖", text: "流程顺畅，结论清晰，共识度较高。", tag: "积极", tagColor: "bg-teal-50 text-teal-600" },
                  { name: "产品经理", icon: "👤", text: "MVP 聚焦停车场景，价值明确。", tag: "积极", tagColor: "bg-teal-50 text-teal-600" },
                  { name: "后端架构师", icon: "🛡️", text: "技术可行，建议预留扩展性与观测能力。", tag: "积极", tagColor: "bg-teal-50 text-teal-600" },
                  { name: "测试工程师", icon: "🧪", text: "关注异常与边界覆盖，建议补充试点验证。", tag: "中性", tagColor: "bg-blue-50 text-blue-600" },
                  { name: "数据分析师", icon: "📊", text: "需完善埋点与口径定义，便于效果评估。", tag: "中性", tagColor: "bg-blue-50 text-blue-600" },
                ].map((role, i) => (
                  <div key={i} className="bg-white rounded-xl p-3 border border-slate-200 shadow-sm flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-6 h-6 rounded bg-slate-100 flex items-center justify-center text-xs">
                          {role.icon}
                        </div>
                        <span className="text-xs font-semibold text-slate-800">{role.name}</span>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed mb-3">
                        {role.text}
                      </p>
                    </div>
                    <div className="flex justify-end">
                      <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${role.tagColor}`}>
                        {role.tag}
                      </span>
                    </div>
                  </div>
               ))}
               {/* Last role card */}
                <div className="bg-white rounded-xl p-3 border border-slate-200 shadow-sm flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-6 h-6 rounded bg-slate-100 flex items-center justify-center text-xs">
                        ⚖️
                      </div>
                      <span className="text-xs font-semibold text-slate-800">法务与合规</span>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed mb-3">
                      合规风险可控，需确认数据使用边界。
                    </p>
                  </div>
                  <div className="flex justify-end">
                    <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-teal-50 text-teal-600">
                      积极
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* 行动项 */}
            <div>
              <h3 className="flex items-center gap-2 text-slate-900 font-semibold mb-4">
                <ListTodo className="w-5 h-5 text-blue-600" />
                行动项 / Next Actions
              </h3>
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                <table className="w-full text-sm text-left">
                  <thead className="text-xs text-slate-500 bg-slate-50/80 border-b border-slate-200">
                    <tr>
                      <th className="px-4 py-3 font-medium w-12 text-center">#</th>
                      <th className="px-4 py-3 font-medium">行动项</th>
                      <th className="px-4 py-3 font-medium w-32">负责人</th>
                      <th className="px-4 py-3 font-medium w-32">截止时间</th>
                      <th className="px-4 py-3 font-medium w-24 text-center">优先级</th>
                      <th className="px-4 py-3 font-medium w-24 text-center">状态</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {[
                      { id: 1, action: "明确停车场数据接入清单与接口规范", owner: "后端架构师", date: "2025-05-23", priority: "高", status: "进行中" },
                      { id: 2, action: "设计并评审优惠校检与分流流程", owner: "产品经理", date: "2025-05-23", priority: "高", status: "进行中" },
                      { id: 3, action: "完成风控规则与异常订单处理方案", owner: "测试工程师", date: "2025-05-30", priority: "中", status: "待开始" },
                      { id: 4, action: "搭建埋点与监控指标看板", owner: "数据分析师", date: "2025-05-30", priority: "中", status: "待开始" },
                      { id: 5, action: "法务合规审查与数据使用协议确认", owner: "法务与合规", date: "2025-05-26", priority: "中", status: "进行中" },
                    ].map((row) => (
                      <tr key={row.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="px-4 py-3 text-slate-500 text-center">{row.id}</td>
                        <td className="px-4 py-3 text-slate-800">{row.action}</td>
                        <td className="px-4 py-3 text-slate-600">{row.owner}</td>
                        <td className="px-4 py-3 text-slate-600">{row.date}</td>
                        <td className="px-4 py-3 text-center">
                          {row.priority === '高' ? (
                            <span className="text-xs font-medium text-red-600 bg-red-50 px-2 py-0.5 rounded">高</span>
                          ) : (
                            <span className="text-xs font-medium text-orange-600 bg-orange-50 px-2 py-0.5 rounded">中</span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-center">
                          {row.status === '进行中' ? (
                            <span className="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-0.5 rounded">进行中</span>
                          ) : (
                            <span className="text-xs font-medium text-slate-600 bg-slate-100 px-2 py-0.5 rounded">待开始</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

          </div>

          {/* Right Column (Span 1) */}
          <div className="lg:col-span-1 h-full flex flex-col">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-slate-900 font-semibold flex items-center gap-2">
                <span>AI 生成纪要</span>
                <span className="text-xs font-normal text-slate-500">(Markdown 预览)</span>
              </h3>
              <div className="flex items-center gap-2">
                <button className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-blue-600 hover:bg-blue-50 rounded transition-colors border border-blue-100">
                  <Download className="w-3 h-3" />
                  导出 Markdown
                </button>
                <button className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-red-600 hover:bg-red-50 rounded transition-colors border border-red-100">
                  <FileText className="w-3 h-3" />
                  导出 PDF
                </button>
              </div>
            </div>
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 flex-1 overflow-auto max-h-[800px]">
              <div className="font-mono text-sm leading-relaxed text-slate-700 whitespace-pre-wrap">
{`# 高质量多 Agent 研讨纪要

## 1. 最终结论摘要
同意采用分阶段实施路线。先以停车优惠校检为核心能力上线 MVP，覆盖主要停车场景与支付链路闭环，目标在 8 周内上线试点；并行完成数据埋点与风控框架搭建，为后续能力扩展与 AI 优化奠定基础。

> **背景说明**
> - 会议主题：企业级差旅服务系统（V2.0 智能化重构）
> - 结束时间：2025-05-16 16:42
> - 参与角色：AI 主持人、产品经理、后端架构师、测试工程师、数据分析师、法务与合规

## 2. 关键决策
- **采用分阶段路线**：MVP 阶段聚焦停车优惠校检...
- **技术方案**：微服务架构，事件驱动，Kafka + MySQL + Redis...
- **上线计划**：8 周内上线试点，灰度发布...

## 3. 行动项
（详见左侧行动项表格）
...`
}
              </div>
            </div>
          </div>
        </div>
        
        {/* Footer */}
        <div className="mt-12 text-center text-sm text-slate-400">
          本次研讨由 Agora AI 生成，如有错误请以实际业务决策为准。
        </div>

      </main>
    </div>
  );
}
