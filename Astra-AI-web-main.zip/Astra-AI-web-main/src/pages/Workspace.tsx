import React from 'react';
import { Navbar } from '../components/dashboard/Navbar';
import { WorkspaceLeftPanel } from '../components/workspace/WorkspaceLeftPanel';
import { WorkspaceCenterPanel } from '../components/workspace/WorkspaceCenterPanel';
import { WorkspaceRightPanel } from '../components/workspace/WorkspaceRightPanel';

export function Workspace() {
  return (
    <div className="h-screen bg-[#F8FAFC] flex flex-col font-sans overflow-hidden">
      <Navbar activePage="工作台" />
      <div className="flex-1 flex gap-4 p-4 overflow-hidden">
        <WorkspaceLeftPanel />
        <WorkspaceCenterPanel />
        <WorkspaceRightPanel />
      </div>
    </div>
  );
}
