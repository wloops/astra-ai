import React from "react";
import { useNavigate } from "react-router-dom";
import {
  Folder,
  Folders,
  FileText,
  HelpCircle,
  Bot,
  User,
  Users,
  Code,
  CheckSquare,
  Network,
  ExternalLink,
  Info,
  Rocket,
  RefreshCw,
  FileSearch,
} from "lucide-react";
import { cn } from "../../lib/utils";

export function StartSessionForm() {
  const navigate = useNavigate();

  return (
    <div className="bg-white rounded-[24px] shadow-sm border border-slate-200/60 overflow-hidden flex flex-col h-full relative">
      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto w-full">
        {/* Section 1: Parameters */}
        <div className="px-8 pt-8 pb-6 border-b border-slate-100">
          <h2 className="text-xl font-bold text-slate-900 mb-6">
            发起研讨会议
          </h2>

          <div className="space-y-4">
            {/* Project Row */}
            <div className="flex items-start md:items-center py-2 relative">
              <div className="w-[80px] shrink-0 flex items-center gap-2 text-slate-600 font-medium text-sm">
                <Folder className="w-4 h-4" />
                <span>项目</span>
              </div>
              <div className="flex-1 text-slate-900 text-sm pl-4 pr-32">
                企业极速差旅报销系统（V2.0 智能化重构）
              </div>
              <button className="absolute right-0 top-1.5 flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-blue-600 bg-blue-50 border border-blue-100 rounded-md hover:bg-blue-100 transition-colors">
                <Folder className="w-3.5 h-3.5" />
                <span>选择项目</span>
              </button>
            </div>

            <div className="h-px bg-slate-100 w-full" />

            {/* Scene Row */}
            <div className="flex items-start md:items-center py-2 relative">
              <div className="w-[80px] shrink-0 flex items-center gap-2 text-slate-600 font-medium text-sm">
                <Folders className="w-4 h-4" />
                <span>场景</span>
              </div>
              <div className="flex-1 text-slate-900 text-sm pl-4 pr-32">
                需求澄清
              </div>
              <button className="absolute right-0 top-1.5 flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-blue-600 bg-white border border-slate-200 rounded-md hover:bg-slate-50 transition-colors">
                <RefreshCw className="w-3.5 h-3.5" />
                <span>更换场景</span>
              </button>
            </div>

            <div className="h-px bg-slate-100 w-full" />

            {/* Topic Row */}
            <div className="flex items-start py-2">
              <div className="w-[80px] shrink-0 flex items-center gap-2 text-slate-600 font-medium text-sm pt-2">
                <HelpCircle className="w-4 h-4" />
                <span>议题</span>
              </div>
              <div className="flex-1 pl-4 relative">
                <textarea
                  className="w-full h-[100px] bg-white border border-slate-200 rounded-xl p-4 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 resize-none transition-all placeholder-slate-400"
                  defaultValue="当员工提交 200 元（含）以下的打车或餐饮发票时，如何支持自动识别并自动结算？"
                />
                <div className="absolute bottom-3 right-3 text-xs text-slate-400 font-medium">
                  40/500
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Section 2: Roles */}
        <div className="px-8 py-6 border-b border-slate-100">
          <div className="flex items-center gap-2 mb-6 text-slate-900 font-bold text-lg">
            <Users className="w-5 h-5 text-slate-500" />
            <span>参与角色</span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Role 1 */}
            <div className="border border-teal-200 bg-teal-50/30 rounded-xl p-4 relative flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-teal-100 flex items-center justify-center shrink-0 border border-teal-200 shadow-sm">
                <Bot className="w-6 h-6 text-teal-600" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-slate-900 text-sm">
                    AI 主持人
                  </span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-teal-100 text-teal-700">
                    必选
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1 leading-snug">
                  把控研讨节奏，提问澄清，归纳结论并输出行动项。
                </p>
              </div>
            </div>

            {/* Role 2 */}
            <div className="border border-slate-200 bg-white rounded-xl p-4 relative flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center shrink-0 border border-blue-200 shadow-sm text-blue-600 font-bold text-lg">
                <User className="w-5 h-5" fill="currentColor" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-slate-900 text-sm">
                    产品经理
                  </span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-teal-100 text-teal-700">
                    必选
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1 leading-snug">
                  聚焦用户价值与需求范围，梳理流程与规则设计要点。
                </p>
              </div>
            </div>

            {/* Role 3 */}
            <div className="border border-slate-200 bg-white rounded-xl p-4 relative flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center shrink-0 border border-indigo-200 shadow-sm text-indigo-600">
                <Code className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-slate-900 text-sm">
                    后端架构师
                  </span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-teal-100 text-teal-700">
                    必选
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1 leading-snug">
                  评估技术方案可行性，关注系统设计与集成实现。
                </p>
              </div>
            </div>

            {/* Role 4 */}
            <div className="border border-slate-200 bg-white rounded-xl p-4 relative flex items-start gap-3">
              <div className="absolute top-2 right-2">
                <CheckSquare className="w-4 h-4 text-blue-500" />
              </div>
              <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center shrink-0 border border-purple-200 shadow-sm text-purple-600">
                <FileSearch className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-slate-900 text-sm">
                    测试工程师
                  </span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-blue-100 text-blue-700">
                    可选
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1 leading-snug">
                  识别测试风险与覆盖点，设计测试策略与验收标准。
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Section 3: Context Preview */}
        <div className="px-8 pt-6 pb-24">
          <div className="flex items-center gap-2 mb-4 text-slate-900 font-bold text-lg">
            <FileText className="w-5 h-5 text-slate-500" />
            <span>项目上下文预览</span>
          </div>

          <div className="bg-slate-50/50 border border-slate-200 rounded-xl p-4">
            {/* Tabs */}
            <div className="flex items-center gap-6 border-b border-slate-200 mb-4 px-2">
              <button className="text-sm font-semibold text-blue-600 border-b-2 border-blue-600 pb-2 -mb-[1px]">
                当前架构
              </button>
              <button className="text-sm font-medium text-slate-500 hover:text-slate-800 pb-2 -mb-[1px]">
                当前进展
              </button>
            </div>

            <div className="flex gap-4 px-2">
              <div className="w-5 h-5 shrink-0 mt-0.5 text-slate-400">
                <Network className="w-5 h-5" />
              </div>
              <p className="text-sm text-slate-600 leading-relaxed flex-1">
                微服务架构，前端 React + TypeScript，后端 Spring Boot，数据存储
                MySQL + Redis，消息队列 Kafka，文件存储对象存储
                (OSS)。已集成企业 SSO 与发票识别服务。
              </p>
              <button className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1 shrink-0 self-end">
                查看完整上下文
                <ExternalLink className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Sticky Bottom Actions */}
      <div className="absolute bottom-0 left-0 w-full bg-white/80 backdrop-blur-md border-t border-slate-200/80 px-8 py-4 flex items-center justify-between z-10 shadow-[0_-4px_20px_rgb(0,0,0,0.02)]">
        <div className="flex items-center gap-3">
          <div className="flex -space-x-2">
            <div className="w-8 h-8 rounded-full border-2 border-white bg-teal-100 flex items-center justify-center shrink-0 shadow-sm z-40">
              <Bot className="w-4 h-4 text-teal-600" />
            </div>
            <img
              className="w-8 h-8 rounded-full border-2 border-white bg-slate-100 object-cover shadow-sm z-30"
              src="https://api.dicebear.com/7.x/notionists/svg?seed=Annie"
              alt="Avatar 1"
            />
            <img
              className="w-8 h-8 rounded-full border-2 border-white bg-slate-100 object-cover shadow-sm z-20"
              src="https://api.dicebear.com/7.x/notionists/svg?seed=George"
              alt="Avatar 2"
            />
            <img
              className="w-8 h-8 rounded-full border-2 border-white bg-slate-100 object-cover shadow-sm z-10"
              src="https://api.dicebear.com/7.x/notionists/svg?seed=Sam"
              alt="Avatar 3"
            />
            <div className="w-8 h-8 rounded-full border-2 border-white bg-slate-50 flex items-center justify-center text-xs font-semibold text-slate-600 shadow-sm z-0">
              +2
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-sm text-slate-500 font-medium">
            <span>6 位参与者将加入研讨</span>
            <Info className="w-4 h-4" />
          </div>
        </div>

        <button 
          onClick={() => navigate('/workspace')}
          className="px-6 py-3 bg-gradient-to-br from-teal-500 to-blue-600 hover:opacity-90 transition-opacity text-white text-base font-semibold rounded-xl flex items-center gap-2 shadow-lg shadow-blue-500/20"
        >
          <Rocket className="w-4 h-4" fill="currentColor" />
          启动智能研讨
        </button>
      </div>
    </div>
  );
}
